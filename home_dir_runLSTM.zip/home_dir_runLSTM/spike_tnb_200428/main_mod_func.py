def main(input1, input2, input3, input4, input5):
    
#    if __name__ == '__main__':
        import pathlib
        from src import dispatcher
        import sys,os
    
      #  argv = sys.argv
       # if len(argv)!=6: #5:
       #     print('Error in usage: python3 main.py lstm_stack {train,eval,generate} {autoregression,fromdata} {threshold,sample} {configfile name}')
       #     sys.exit()
    
        MODEL = input1 # argv[1] #choose lstm_stack
        MODE = input2 # argv[2] # choose {train,eval,generate}
        GENERATE_MODE = input3 # argv[3] # choose {autoregression,fromdata}
        QUANTIZATION_MODE = input4 # argv[4] # choose {threshold,sample}
        CONFIGFILE_NAME = 'data/' + input5 # argv[5] # choose {threshold,sample}
    
        rootdir = pathlib.Path(__file__).parent
        dispatcher.dispatch(str(rootdir), 'log_config.ini', CONFIGFILE_NAME, MODEL , MODE, GENERATE_MODE, QUANTIZATION_MODE)
    

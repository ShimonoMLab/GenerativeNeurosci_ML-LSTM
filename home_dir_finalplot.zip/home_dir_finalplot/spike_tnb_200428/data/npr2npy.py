""" 2020/02/06 go shibata

make npy file
"""
import numpy as np


segment_size = 1_000_000

file = './190423_npr.txt'
with open(file) as f:
    lines = f.readlines()

_, n_neuron = lines[0].split()
n_neuron = int(n_neuron)
_, n_time = lines[1].split()
n_time = int(n_time)

spikes = np.zeros((n_time, n_neuron), dtype=bool)
for line in lines[2:]:
    onset, bin = map(int, line.split())
    spikes[onset, bin] = 1

assert len(lines)-2 == np.count_nonzero(spikes == True)

split_spikes = np.array([
    spikes[i*segment_size:(i+1)*segment_size]
    for i in range(0, len(spikes)//segment_size)])

np.save('./spikes.npy', spikes)
np.save('./split_spikes.npy', split_spikes)

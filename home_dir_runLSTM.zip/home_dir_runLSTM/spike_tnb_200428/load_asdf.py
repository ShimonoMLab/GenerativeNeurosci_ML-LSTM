def main(infile,outfile):
    import sys,os
    import scipy.io
    
    # argv = sys.argv
    # if len(argv)!=3:
    #  print('Error in usage: ./this.py in.mat out.txt')
    #  sys.exit()
    
 #   infile = '190423_asdf.mat'
 #   outfile = '190423_npy2.txt'
    
    matdata = scipy.io.loadmat(infile)
    
    nNeuron = len(matdata['asdf'][0])-2
    nTime = matdata['asdf'][0][-1][0][1]
   # print(nNeuron,nTime)
    
    # return(nNeuron)
    #print matdata['asdf'][0][-1][0]
    
    with open(outfile, mode='w') as f:
      f.write("#nNeuron\t"+str(nNeuron)+"\n")
      f.write("#nTime\t"+str(nTime)+"\n")
      for i in range(nNeuron):
        l = len(matdata['asdf'][0][i+1][0])
        f.write(str(i)+"\t"+str(l)+" : ")
        for j in range(l):
          f.write(str(matdata['asdf'][0][i+1][0][j])+"\t")
        f.write("\n")
        
     #   return()
    print("Number of neurons is ", nNeuron)
    print("Time step is ", nTime)
    return(nNeuron)
    
    # binaryMat = [[0] * nTime for i in range(nNeuron)]
    # 
    # print len(binaryMat)
    # print len(binaryMat[0])
    
    # for i in matdata['asdf'][0][1][0]:
    #   print i
    


import load_asdf
import npr2npy_mod

##  mat 2 text middle file
load_asdf.main('190423_asdf.mat','190423_npr2.txt')

## text middle file to text final file
import subprocess
 
def main():
 
    # call C/C++ executable file
    cmd = "./a.out  190423_npr2.txt 190423_npr3.txt"
    c = subprocess.check_output(cmd.split())
 
if __name__ == '__main__':
    main()
   
## from text file to npy file
npr2npy_mod.main( '190423_npr3.txt')
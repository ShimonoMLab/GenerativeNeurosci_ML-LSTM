
close all;
clear all;

clear data*


for nn1 =  1:16;

disp(['nn1=',num2str(nn1)]);
        
    if     nn1 == 1;  data_name1 = 'LOD191008001';
    elseif nn1 == 2;  data_name1 = 'LD201201001';
    elseif nn1 == 3;  data_name1 = 'LFD190806001';
    elseif nn1 == 4;  data_name1 = 'LF210715001';
    elseif nn1 == 5;  data_name1 = 'LFV201215001';
    elseif nn1 == 6;  data_name1 = 'LV191217001';
    elseif nn1 == 7;  data_name1 = 'LOV210706001';
    elseif nn1 == 8;  data_name1 = 'LO220927001';
    elseif nn1 == 9;  data_name1 = 'RO200707001';
    elseif nn1 == 10; data_name1 = 'ROV200908001';
    elseif nn1 == 11; data_name1 = 'RV211130001';
    elseif nn1 == 12; data_name1 = 'RFV210810001';
    elseif nn1 == 13; data_name1 = 'RF210622001';
    elseif nn1 == 14; data_name1 = 'RFD200929001';
    elseif nn1 == 15; data_name1 = 'RD211102001';
    elseif nn1 == 16; data_name1 = 'ROD210518001';
    end
         
    
    for nn2 = 1:16;
        
disp(['nn2=',num2str(nn2)]);
        close all;
    
        if     nn2 == 1;  data_name2 = 'LOD191008001';
        elseif nn2 == 2;  data_name2 = 'LD201201001';
        elseif nn2 == 3;  data_name2 = 'LFD190806001';
        elseif nn2 == 4;  data_name2 = 'LF210715001';
        elseif nn2 == 5;  data_name2 = 'LFV201215001';
        elseif nn2 == 6;  data_name2 = 'LV191217001';
        elseif nn2 == 7;  data_name2 = 'LOV210706001';
        elseif nn2 == 8;  data_name2 = 'LO220927001';
        elseif nn2 == 9;  data_name2 = 'RO200707001';
        elseif nn2 == 10; data_name2 = 'ROV200908001';
        elseif nn2 == 11; data_name2 = 'RV211130001';
        elseif nn2 == 12; data_name2 = 'RFV210810001';
        elseif nn2 == 13; data_name2 = 'RF210622001';
        elseif nn2 == 14; data_name2 = 'RFD200929001';
        elseif nn2 == 15; data_name2 = 'RD211102001';
        elseif nn2 == 16; data_name2 = 'ROD210518001';
        end    
        
        
        
        
        
        for nn3 =  1:16;
            if     nn3 == 1;  data_name3 = 'LD200609001';
            elseif nn3 == 2;  data_name3 = 'LF211207001';
            elseif nn3 == 3;  data_name3 = 'LFD190423001';
            elseif nn3 == 4;  data_name3 = 'LFV200615001';
            elseif nn3 == 5;  data_name3 = 'LO210126001';
            elseif nn3 == 6;  data_name3 = 'LOD190910001';
            elseif nn3 == 7;  data_name3 = 'LOV200114001';
            elseif nn3 == 8;  data_name3 = 'LV210216001';
            elseif nn3 == 9;  data_name3 = 'RD200526001';
            elseif nn3 == 10; data_name3 = 'RF210525001';
            elseif nn3 == 11; data_name3 = 'RFD200901001';
            elseif nn3 == 12; data_name3 = 'RFV200714001';
            elseif nn3 == 13; data_name3 = 'RO201027001';
            elseif nn3 == 14;  data_name = 'ROD210511001';
            elseif nn3 == 15; data_name3 = 'ROV201006001';
            elseif nn3 == 16; data_name3 = 'RV200728001';
            end
            
            for nn4 =  1:16;
                if     nn4 == 1;  data_name4 = 'LD200609001';
                elseif nn4 == 2;  data_name4 = 'LF211207001';
                elseif nn4 == 3;  data_name4 = 'LFD190423001';
                elseif nn4 == 4;  data_name4 = 'LFV200615001';
                elseif nn4 == 5;  data_name4 = 'LO210126001';
                elseif nn4 == 6;  data_name4 = 'LOD190910001';
                elseif nn4 == 7;  data_name4 = 'LOV200114001';
                elseif nn4 == 8;  data_name4 = 'LV210216001';
                elseif nn4 == 9;  data_name4 = 'RD200526001';
                elseif nn4 == 10; data_name4 = 'RF210525001';
                elseif nn4 == 11; data_name4 = 'RFD200901001';
                elseif nn4 == 12; data_name4 = 'RFV200714001';
                elseif nn4 == 13; data_name4 = 'RO201027001';
                elseif nn4 == 14;  data_name4 = 'ROD210511001';
                elseif nn4 == 15; data_name4 = 'ROV201006001';
                elseif nn4 == 16; data_name4 = 'RV200728001';
                end
         
                for posneg = 1:2;
                    
                    load_name  = ['./txts/',data_name1,'_',data_name2,'_',data_name2,'_','coefficient_linear','.txt'];
                
                    if     posneg == 1; data_pos(nn1,nn2) = csvread(load_name);
                    elseif posneg == 2; data_neg(nn1,nn2) = csvread(load_name);
          
                    
                    end   
                    
                end
                
                data_pos(nn1,nn2) = csvread(load_name);
                data_neg(nn1,nn2) = csvread(load_name);

                
                load_name2  = ['./txts/',data_name3,'_',data_name4,'_',data_name4,'_','coefficient_linear','.txt'];
                
                data_pos2(nn3,nn4) = csvread(load_name2);
                data_neg2(nn3,nn4) = csvread(load_name2);
                
            end
    data_pos(:,nn2) = data_pos(:,nn2)/max(data_pos(:,nn2));
    data_pos(:,nn2) = data_neg(:,nn2)/max(data_neg(:,nn2));
    data_pos2(:,nn4) = data_pos2(:,nn4)/max(data_pos2(:,nn4)); 
    data_neg2(:,nn4) = data_neg2(:,nn4)/max(data_neg2(:,nn4));
        end
    end
end
        
   

data_pos_all = cat(2,data_pos,data_pos2);

cluster_number = 8;

rng(1)
    tree = linkage(data_pos_all,'average','spearman'); 
    names = {'LOD','LO','LFD','LF','LFV','LV','LOV','LO','RO','ROV','RV','RFV', 'RF' ,'RFD','RD','ROD'};
    
    D = pdist(data_pos_all);
    leafOrder = optimalleaforder(tree,D);
    T = cluster(tree,'maxclust',cluster_number);

    %% plotting dendrogram
    figure(20); %jukeizu
    dendrogram(tree,0,'ColorThreshold','default','Reorder',leafOrder);

    names_sorted    = names(leafOrder);
    data_pos_sorted = data_pos(leafOrder,leafOrder);
    data_pos_sorted2 = data_pos2(leafOrder,leafOrder);

   
%%
figure(1); %senzu
plot(diag((data_pos + data_pos2)/2),'LineWidth',2); hold on;  % colorbar;
plot(diag(data_pos),'g.','MarkerSize',15); hold on;  
plot(diag(data_pos2),'r.','MarkerSize',15); hold on;  


title('Corr. (Firing Rate)    red(group1) green(group2)','fontsize',15,'fontname','Arial');
xlabel('Region Index','fontsize',15,'fontname','Arial');
set(gca,'XLim',[1 16],'fontsize',12,'fontname','Arial');
set(gca,'YLim',[-0.1 1.2],'fontsize',12,'fontname','Arial');



%%
figure(110);
imagesc(data_pos_sorted);  colorbar;
title('Firing Rate','fontsize',18,'fontname','Arial');
ylabel('Predicted','fontsize',18,'fontname','Arial');
xlabel('Original','fontsize',18,'fontname','Arial');

xticks([1:16])
xticklabels(names_sorted)

yticks([1:16])
yticklabels(names_sorted)
caxis([0, 1])


figure(111);
imagesc(data_pos_sorted2);  colorbar;
title('Firing Rate','fontsize',18,'fontname','Arial');
ylabel('Predicted','fontsize',18,'fontname','Arial');
xlabel('Original','fontsize',18,'fontname','Arial');

xticks([1:16])
xticklabels(names_sorted)

yticks([1:16])
yticklabels(names_sorted)
caxis([0, 1])


mkdir ./invitro_summary128_EIbalance_diff/
mkdir ./invitro_summary128_EIbalance_diff/figure

print -f20 -djpeg ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_dendrogram_FR_linear_sorted;
print -f20 -deps ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_dendrogram_FR_linear_sorted;
print -f20 -dpdf ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_dendrogram_FR_linear_sorted;

print -f1 -djpeg ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_corr_diag_FR_linear;
print -f1 -deps ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_corr_diag_FR_linear;
print -f1 -dpdf ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_corr_diag_FR_linear;

print -f111 -djpeg ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_colormap_FR_sorted_linear;
print -f111 -deps ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_colormap_FR_sorted_linear;
print -f111 -dpdf ./invitro_summary128_EIbalance_diff/figure/group1VSgroup2_colormap_FR_sorted_linear;

print -f110 -djpeg ./invitro_summary128_EIbalance_diff/figure/2_group1VSgroup2_colormap_FR_sorted_linear;
print -f110 -deps ./invitro_summary128_EIbalance_diff/figure/2_group1VSgroup2_colormap_FR_sorted_linear;
print -f110 -dpdf ./invitro_summary128_EIbalance_diff/figure/2_group1VSgroup2_colormap_FR_sorted_linear;


mkdir ../../data/128neuron_16_!6_eval/

save ../../data/128neuron_16_!6_eval/data_neg_group2 data_neg
save ../../data/128neuron_16_!6_eval/data_pos_group2 data_pos




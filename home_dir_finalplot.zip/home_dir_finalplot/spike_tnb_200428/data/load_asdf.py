def main(infile,outfile):
    import sys
    import os
    import scipy.io
    import numpy as np
    
    # argv = sys.argv
    # if len(argv)!=3:
    #  print('Error in usage: ./this.py in.mat out.txt')
    #  sys.exit()
    
 #   infile = '190423_asdf.mat'
 #   outfile = '190423_npy2.txt'
    
    matdata = scipy.io.loadmat(infile)
    aa = matdata['asdf']
    bb = np.shape(aa)
    nNeuron = bb[0]-2
    
    print("Number of neurons is ", str(nNeuron))
    
  #  nTime = aa[0][-1][0][1] 
    nTime = aa[-1][0][0][-1]

   # print(nNeuron,nTime)
    
    # return(nNeuron)
    #print matdata['asdf'][0][-1][0]
    print(outfile)
    
    with open(outfile, mode='w') as f:
      f.write("#nNeuron\t"+str(nNeuron)+" \n")
     # f.write("#nNeuron\t"+str(nNeuron))
     # f.write("\n")
      print(str(nNeuron))
      f.write("#nTime\t"+str(nTime)+" \n")
      print(str(nTime))
      for i in range(nNeuron):
    #    l = len(matdata['asdf'][0][i+1][0])
    #    print(str(i))
        l = len(aa[i+1][0][0])
        f.write(str(i)+"\t"+str(l)+" : ")
        for j in range(l):
          f.write(str(aa[i+1][0][0][j])+"\t")
        f.write("\n")
        
     #   return()
#    print("Time step is ", nTime, 'This part is currently wrong at L.34 in load_asdf.py. --  Revise here later after running simulation again!')
    return(nNeuron)
    
    # binar yMat =   [[0] * nTime for i in range(nNeuron)]
    # 
    # print len(binaryMat)
    # print len(binaryMat[0])
     
    # for i in matdata['asdf'][0][1][0]:
    #   print i
    

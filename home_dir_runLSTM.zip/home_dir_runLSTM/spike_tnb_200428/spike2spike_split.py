""" 2020/02/18 go shibata
    2020/06/16 masanori shimono
make npr file
"""

def main(data_dir, segment_size):
    import sys,os
    import scipy.io
    import numpy as np
    
    spikes = np.load(data_dir+'/spikes.npy') # , spikes)
    
    split_spikes = np.array([
        spikes[i*segment_size:(i+1)*segment_size]
        for i in range(0, spikes.shape[0]//segment_size)])
    #    for i in range(0, len(spikes)//segment_size)])
    
 #   np.save(data_dir+'spikes.npy', spikes)
    np.save(data_dir+'/split_spikes.npy', split_spikes)

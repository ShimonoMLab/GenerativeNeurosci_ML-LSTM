
close all;
clear all;

for groupID = 1:2
    
    if groupID == 1
        
        load ../../data/128neuron_16_!6_eval/data_neg
        load ../../data/128neuron_16_!6_eval/data_pos
        load ../../conn_all
        
    elseif groupID == 2
        
        load ../../data/128neuron_16_!6_eval/data_neg_group2
        load ../../data/128neuron_16_!6_eval/data_pos_group2
        load ../../conn_all_group2
    end
    
    
    data_neg = data_neg(9:16,9:16);
    data_pos = data_pos(9:16,9:16);
    
    conn_strength_mat = conn_all(9:16,9:16);
    
    mkdir ../../figure
    
    
    figure(14 )
    subplot(2,2,1);
    plot(conn_strength_mat, data_pos,'r.'); hold on;
    title('Excitatory')
    xlabel('Direct connection strength');
    ylabel('FR prediction performance [log_{10}]','FontSize',9);
    
    subplot(2,2,2);
    plot(conn_strength_mat, data_neg,'b.'); hold on;
    title('inhibitory')
    xlabel('Direct connection strength');
    ylabel('FR prediction performance [log_{10}]','FontSize',9);
    subplot(2,2,3);
    title(['Group',num2str(groupID)])
    
    
    conn_strength_mat0(groupID,:,:) = conn_strength_mat;
    data_neg0(groupID,:,:) = data_neg;
    data_pos0(groupID,:,:) = data_pos;
    
    clear data_neg data_pos  conn_strength_mat
    
end

print -f14 -djpeg ../../figure/FRpred_ve_connection_hemiR_group12
print -f14 -deps  ../../figure/FRpred_ve_connection_hemiR_group12
print -f14 -dpdf  ../../figure/FRpred_ve_connection_hemiR_group12



%%

conn_str2      = reshape(conn_strength_mat0,128,1);
sharpness_neg2 = reshape(data_neg0,128,1);
sharpness_pos2 = reshape(data_pos0,128,1);


[r_exc,p_exc] = corr(conn_str2,sharpness_pos2,'Type','Spearman')

[r_inh,p_inh] = corr(conn_str2,sharpness_neg2,'Type','Spearman')

close all;
clear all;

for groupID = 1:2
    
    if groupID == 1
        
        load ../../data/128neuron_16_!6_eval/data_neg
        load ../../data/128neuron_16_!6_eval/data_pos
        
        
    elseif groupID == 2
        
        load ../../data/128neuron_16_!6_eval/data_neg_group2
        load ../../data/128neuron_16_!6_eval/data_pos_group2
        
    end
    
    b = 1;
    a = 1;
    
    
    c = [  0 , b , 2*b ,3*b  ,2*b , 3*b , 2*b ,   b ];
    
    c_all = zeros(8,8);
    for nn = 1:8
        c_all(:,nn) = c(circshift([1:8],nn-1));
    end
    
    
    distance_mat = [c_all+ a*0];
    
    
    
    data_neg = data_neg(9:16,9:16);
    data_pos = data_pos(9:16,9:16);
    
    
    mkdir ../../figure
    
    figure(14 )
    subplot(2,2,1);
    plot(distance_mat, data_pos,'r.'); hold on;
    title('Excitatory')
    xlabel('distance');
    ylabel('Firing rate prediction performance [log_{10}]');
    set(gca,'Xlim',[-0.2,3.2])
    
    subplot(2,2,2);
    plot(distance_mat, data_neg,'b.'); hold on;
    title('Inhibitory')
    xlabel('distance');
    ylabel('Firing rate prediction performance [log_{10}]');
    set(gca,'Xlim',[-0.2,3.2])
    
    distance_mat0(groupID,:,:) = distance_mat;
    data_neg0(groupID,:,:) = data_neg;
    data_pos0(groupID,:,:) = data_pos;
    
    
    clear data_neg data_pos  conn_strength_mat
    
end


print -f14 -djpeg ../../figure/Firingratepred_ve_distance_hemiR_group12
print -f14 -deps  ../../figure/Firingratepred_ve_distance_hemiR_group12
print -f14 -dpdf  ../../figure/Firingratepred_ve_distance_hemiR_group12


%%

distance_mat2      = reshape(distance_mat0,128,1);
sharpness_neg2 = reshape(data_neg0,128,1);
sharpness_pos2 = reshape(data_pos0,128,1);

rng('default')


[r_pos,p_pos] = corr(distance_mat2,sharpness_pos2,'Type','Spearman')
[r_neg,p_neg] = corr(distance_mat2,sharpness_neg2,'Type','Spearman')


figure(100)
X = categorical({'e','f'});
X = reordercats(X,{'e','f'});
Y = [r_pos r_neg];
bar(X,Y)


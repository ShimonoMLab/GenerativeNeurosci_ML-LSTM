""" 2020/02/18 go shibata
    2020/06/16 masanori shimono
make npr file
"""

def main(data_dir, input):
    import sys,os
    import scipy.io
    import numpy as np
    
    file = data_dir + input
    with open(file) as f:
        lines = f.readlines()
    
    _, n_neuron = lines[0].split()
    n_neuron = int(n_neuron)
    _, n_time = lines[1].split()
    n_time = int(n_time)    
    spikes = np.zeros((n_time+1, n_neuron), dtype=bool)
    
    for line in lines[2:]:
        onset, bin = map(int, line.split())
        spikes[onset, bin] = 1
    
  #  assert len(lines)-2 == np.count_nonzero(spikes == True)
    
#     split_spikes = np.array([
#         spikes[i*segment_size:(i+1)*segment_size]
#         for i in range(0, len(spikes)//segment_size)])
    
    np.save(data_dir+'spikes0.npy', spikes)
  #  np.save(data_dir+'split_spikes.npy', split_spikes)
    del onset, bin, line
""" 2020/02/18 go shibata

make npr file
"""
def main(input, input2):

        
    import os
    import sys
    
    from argparse import ArgumentParser
    import numpy as np
    
    data = np.load(input) 
    
    if len(data.shape) == 2:
        n_time, n_neuron = data.shape
    else:
        _, n_time, n_neuron = data.shape
        
    lines = [
        f'#nNeuron\t{n_neuron}',
        f'#nTime\t{n_time}',
    ]
    
    nz = data.nonzero()
    for datum in zip(*nz):
        if len(datum) == 2:
            time, dim = datum
        else:
            _, time, dim = datum
        lines.append(f'{time}\t{dim}')
    
    assert len(lines)-2 == len(nz[0])
    
    filename = input2 # sys.argv[2] # 'generated.txt'  # f'{os.path.splitext(args.file)[0]}.txt'
    with open(filename, mode='w') as f:
        f.write('\n'.join(lines) + '\n')


close all;
% cd /Volumes/HDPH-UT/home_dir_finalplot/spike_tnb_200428/Analyse/AnalysisTool

disp('An exmaple predicting between same data')
disp('This pair is not exactly same as the figure 3 (d)-(f), but the essense is same.')

 data1 = 'RF210622001'
 data2 = 'RF210622001'
 
[sharpness,posratio] = theta_dis_eval_ver3(...
['../../data/128neuron_rep1/',data1,'_',data1,'/',data2,'/128_128_128_gamma002_epo350/lstm_stack'],...
 'BigramZSignificance_train_val_test_D11.txt',...
['./txts/',data2,'_',data1,'_',data1,'_pos.txt'],...
['./txts/',data2,'_',data1,'_',data1,'_neg.txt']);

pause(5);


%%
close all;
% cd /Volumes/HDPH-UT/home_dir_finalplot/spike_tnb_200428/Analyse/AnalysisTool

disp('An exmaple predicting between different data')
disp('This pair is not exactly same as the figure 4 (d)-(f), but the essense is same.')

 data1 = 'RF210622001'
 data2 = 'LFD190423001'
  
[sharpness,posratio] = theta_dis_eval_ver3(...
['../../data/128neuron_rep1/',data1,'_',data1,'/',data2,'/128_128_128_gamma002_epo350/lstm_stack'],...
 'BigramZSignificance_train_val_test_D11.txt',...
['./txts/',data2,'_',data1,'_',data1,'_pos.txt'],...
['./txts/',data2,'_',data1,'_',data1,'_neg.txt']);

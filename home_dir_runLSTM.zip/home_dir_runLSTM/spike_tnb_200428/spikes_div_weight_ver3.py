# def main(data_dir, div_time, select_time):   20210729
def main(data_dir, div_count0, start_time_step0 , segment_step0, sep_size0 ):
    import sys
    import os
    import scipy.io
    import numpy as np
    
    #data_list = ['190423','190514','190604','190611','190617','190806']
    # data_list= ['data_01','data_02','data_03','data_04']
    
#    with open(data_dir + '/cell_categ_exc.txt','r') as a:
#        cell_categ = a.read()
#        cell_categ = cell_categ.split('\n')
#        
#    with open(data_dir +'/layer_categ.txt','r') as b:
#        layer_categ = b.read()
#        layer_categ = layer_categ.split('\n')
        

    ##loading the data1
#    infile1 = data_dir1 + '/asdf.mat'
#    matdata = scipy.io.loadmat(infile1)  ##
#    aa1 = matdata['asdf']                ##load txt     
    #aa1 = aa1[0]
    
    ##loading the data
  #  for i in range(4):
     #   infile1 = os.path.dirname(os.path.abspath('__file__')) +'/' + data_list[i] + '/spikes.npy' 
    infile1 = data_dir + 'spikes0.npy' 
    aa1  = np.load(infile1)
    bb1  = np.shape(aa1)
#    aa1 = aa1.T
                 
    start_p = int(start_time_step0) # start_p = int(bb1[0] * (select_time-1) / div_time) 20210729nakajima
   # end_p   = int(start_time_step0 + segment_step0 / div_count0)  # end_p   = int(bb1[0] * select_time     / div_time)
    end_p   = int(start_time_step0 + sep_size0) #round(segment_step0 / div_count0))  # end_p   = int(bb1[0] * select_time     / div_time)
    
   # aa1 = np.delete(aa1,slice(end_p,int(bb1[0])), axis=0)
   # aa1 = np.delete(aa1,slice(0,start_p), axis=0)
    
    aa100 = np.delete(aa1,slice(end_p,int(bb1[0])), axis=0)
      #  aa10 = np.delete(aa1,slice(0,start_p), axis=0)
    aa10 = np.delete(aa100,slice(0,start_p), axis=0)
    
    timestep_num = aa10.shape[0]
    neuron_num   = aa10.shape[1]

   # import copy
   # aa11 = aa10.T.astype(int)
    aa11 = aa10.T.astype(np.int32)
    # aa11 =aa10.T.astype(np.int)
    
    
#    aa11 =aa1.T.astype(np.bool)

  #  for t1 in range(timestep_num):
#    for n1 in range(neuron_num):
#          #  aa11[n1] = aa11[n1] * (int(cell_categ[n1]) - 0.5) * 2 * (int(layer_categ[n1]))
  #        aa11[n1] = aa11[n1] * (int(cell_categ[n1]) + 1) * (int(layer_categ[n1]))  
         
  #  print(aa11)
    aa12 = aa11.T
  #  print(aa12)
  #  aa13 = np.array(aa12, dtype=float)
  #  print(aa13)
    #nNeuron1 = bb1[0]-2
        
    return(aa12)
######################################
 
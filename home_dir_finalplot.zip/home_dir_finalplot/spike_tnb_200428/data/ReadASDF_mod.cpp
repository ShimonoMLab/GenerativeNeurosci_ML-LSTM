//g++ -O2 -I/Users/eita/boost_1_63_0 -I/Users/eita/Dropbox/Research/Tool/All/ ReadASDF.cpp -o ReadASDF
#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cmath>
#include<cassert>
#include<algorithm>

using namespace std;

class NeuroEvt{
public:
	int tick;
	int ID;
};//endclass NeuroEvt

class LessNeuroEvt{
public:
	bool operator()(const NeuroEvt& a, const NeuroEvt& b){
		if(a.tick < b.tick){
			return true;
		}else if(a.tick==b.tick){
			if(a.ID < b.ID){
				return true;
			}else{
				return false;
			}//endif
		}else{//if a.tick > b.tick
			return false;
		}//endif
	}//end operator()
};//end class LessNeuroEvt
//sort(evts.begin(), evts.end(), LessNeuroEvt());

class Asdf{
public:
	int nNeuron;
	int nTime;
	vector<vector<int> > ontime;//nNeuron x #(ontimes)
	vector<NeuroEvt> evts;

	void ReadFile(string filename,int mode=0){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		string str;
		stringstream ss;

		ifstream ifs(filename.c_str());

		ifs>>s[1]>>nNeuron;
		getline(ifs,s[99]);
		ifs>>s[1]>>nTime;
		getline(ifs,s[99]);

		ontime.clear();
		ontime.resize(nNeuron);

		for(int i=0;i<nNeuron;i+=1){
			ifs>>v[0]>>v[1]>>s[2];
			ontime[i].resize(v[1]);
			for(int j=0;j<v[1];j+=1){
				ifs>>v[10];
				ontime[i][j]=v[10];
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		ifs.close();
	}//end ReadFile

	void WriteFile(string filename, int mode=0){
		ofstream ofs(filename.c_str());
		ofs<<"#nNeuron\t"<<nNeuron<<"\n";
		ofs<<"#nTime\t"<<nTime<<"\n";

		if(mode==1){

			for(int n=0;n<evts.size();n+=1){
				ofs<<evts[n].tick<<"\t"<<evts[n].ID<<"\n";
			}//endfor n

		}//endif

		ofs.close();
	}//end WriteFile

	void GetNeuroEvts(){
		evts.clear();
		NeuroEvt evt;
		for(int i=0;i<ontime.size();i+=1){
			for(int j=0;j<ontime[i].size();j+=1){
				evt.tick=ontime[i][j];
				evt.ID=i;
				evts.push_back(evt);
			}//endfor j
		}//endfor i
		sort(evts.begin(), evts.end(), LessNeuroEvt());
	}//end GetNeuroEvts

};//endclass Asdf


int main(int argc, char** argv) {
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	string str;
	stringstream ss;

	if(argc!=3){cout<<"Error in usage: $./this in.txt out.txt"<<endl; return -1;}
	string infile=string(argv[1]);
	string outfile=string(argv[2]);

	Asdf asdf;
	asdf.ReadFile(infile);

	asdf.GetNeuroEvts();
	asdf.WriteFile(outfile,1);

/*
	vector<vector<int> > binaryMat;
	binaryMat.resize(asdf.nTime);
	for(int t=0;t<asdf.nTime;t+=1){
		binaryMat[t].assign(asdf.nNeuron,0);
	}//endfor t
	for(int i=0;i<asdf.ontime.size();i+=1){
		for(int j=0;j<asdf.ontime[i].size();j+=1){
			binaryMat[asdf.ontime[i][j]][i]=1;
		}//endfor j
	}//endfor i

{
	ofstream ofs(outfile.c_str());
	for(int t=0;t<binaryMat.size();t+=1){
//	for(int t=0;t<10000;t+=1){
		for(int i=0;i<binaryMat[t].size();i+=1){
ofs<<binaryMat[t][i]<<"\t";
		}//endfor i
ofs<<"\n";
	}//endfor t
	ofs.close();
}//
*/

	return 0;
}//end main

from torch import nn


class LSTMStack(nn.Module):

    def __init__(self, n_input, n_layer_list, n_hidden_list, n_output):
        super().__init__()
        assert len(n_layer_list) == len(n_hidden_list)
        n_hidden_list.insert(0, n_input)

        lstm_stack = []
        iter = zip(n_layer_list, n_hidden_list[:-1], n_hidden_list[1:])
        for n_layer, n_hidden_pre, n_hidden_post in iter:
            lstm = nn.LSTM(
                input_size=n_hidden_pre,
                hidden_size=n_hidden_post,
                batch_first=True,
                num_layers=n_layer)
            lstm_stack.append(lstm)
        self.lstm_stack = nn.ModuleList(lstm_stack)
        self.fc = nn.Linear(n_hidden_list[-1], n_output)
        self.sigmoid = nn.Sigmoid()

    def forward(self, inputs, hidden_list=None):
        if hidden_list is None:
            hidden_list = [None] * len(self.lstm_stack)
        if len(hidden_list) != len(self.lstm_stack):
            raise ValueError()
        
        new_hidden_list = []
        outputs = inputs
        for lstm, hidden in zip(self.lstm_stack, hidden_list):
            lstm.flatten_parameters()
            outputs, new_hidden = lstm(outputs, hidden)
            new_hidden_list.append(new_hidden)

        x = self.fc(outputs)
        x = self.sigmoid(x)
        return x, new_hidden_list

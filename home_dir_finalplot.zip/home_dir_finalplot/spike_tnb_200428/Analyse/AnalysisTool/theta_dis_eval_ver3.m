function [sharpness,posratio] = theta_dis_eval_ver3(pathname, dataname, sharp, sharp2)

% ratio: ratio of data samples existing between pi/6-pi/3  witin data samples between 0-pi/2
% posratio: ratio of data samples between 0-pi/2 witin all data samples.
% usage:
% [sharpness,posratio] = theta_dis_eval('~/data/train_180731001_190423001_rep2_val_test_180731001/128_128_128_gamma0.02_epo200/lstm_stack', 'BigramZSignificance_train_180731001_190423001_rep2_val_test_180731001_D1.txt');

% pathname = '~/data/train_180731001_190423001_rep2_val_test_180731001/128_128_128_gamma0.02_epo200/lstm_stack'
% dataname = 'BigramZSignificance_train_180731001_190423001_rep2_val_test_180731001_D1.txt'

data = load([num2str(pathname),'/',num2str(dataname)]);
dataxx = load([num2str(sharp)]);

figure(10);
plot([-10:2:10],0*zeros(11),'k--','LineWidth',1); hold on;
plot(0*zeros(11),[-10:2:10],'k--','LineWidth',1);
plot(data(:,3), data(:,4) ,'b.','MarkerSize',0.05); hold on;
ylabel('Predicted','fontsize',25,'fontname','Arial');
xlabel('Original','fontsize',25,'fontname','Arial');
set(gca,'XLim',[-3 7],'fontsize',20,'fontname','Arial');
set(gca,'YLim',[-3 7],'fontsize',20,'fontname','Arial');

figure(1);
subplot(2,2,1); plot(data(:,3),data(:,4),'b.','MarkerSize',0.1);
ylabel('Predicted','fontsize',15,'fontname','Arial');
xlabel('Original','fontsize',15,'fontname','Arial');
set(gca,'XLim',[-3 7],'fontsize',12,'fontname','Arial');
set(gca,'YLim',[-3 7],'fontsize',12,'fontname','Arial');
data_abs = abs(data);
size(data)
size(data_abs)
data_1st_region = (data(:,3)>=0 & data(:,4)>=0);
data0 = data(data_1st_region==1,:);
posratio = length(data0) / length(data);
theta0 = atan(data(data(:,3)>0,4)./data(data(:,3)>0,3));
r0    =  sqrt(data(data(:,3)>0,3).*data(data(:,3)>0,3) + data(data(:,3)>0,4).*data(data(:,3)>0,4));

figure(1);
subplot(2,2,2); plot(theta0,r0,'b.','MarkerSize',1.5);
ylabel('Radius')
xlabel('Theta')
set(gca,'YLim',[0 20],'fontsize',12,'fontname','Arial');
theta_region = [0+pi/24:pi/30:pi/2-pi/24]; % - 90 ~ 90
for kk = 1:length(theta_region)-1
    hist_theta(kk) = sum(theta0 > theta_region(kk) & theta0 < theta_region(kk+1));
end
theta_region2 = [0+pi/24:pi/30:pi/2-pi/24]; % - 90 ~ 90
theta0_neg = atan(data(data(:,3)<0,4)./data(data(:,3)<0,3));
r0_neg    =  sqrt(data(data(:,3)<0,3).*data(data(:,3)<0,3) + data(data(:,3)<0,4).*data(data(:,3)<0,4));
for kk = 1:length(theta_region2)-1
    hist_theta_neg(kk) = sum(theta0_neg > theta_region2(kk) & theta0_neg < theta_region2(kk+1));
end

disp('thetamin')
max(theta0/pi)
min(theta0/pi)
theta_range_now = theta_region(1:end-1) + pi/2;
disp("---------------")
ignore_range = 5;
ignore_center = 3;
disp(hist_theta)
cent = length(theta_range_now)/2;
x = theta_range_now;
xx = theta_range_now([ignore_range : cent-ignore_center, cent+ ignore_center:end - ignore_range]);
y = hist_theta;
yy = hist_theta([ignore_range : cent-ignore_center, cent+ ignore_center:end - ignore_range]);% (ignore_range : end - ignore_range);
p = polyfit(xx,yy,1)
yfit =  p(1) * x  + p(2) ;%
disp(y)
disp(yy)
hist_theta = y - yfit;
hist_theta = hist_theta + abs(min(hist_theta));
disp(hist_theta)
disp("---------------")

figure(1);
subplot(2,2,3); plot(theta_range_now , hist_theta,'b-','LineWidth',2); hold on;
ylabel('Sample Counts')
xlabel('Theta')
hist_theta_rang = hist_theta(ignore_range : end-ignore_range)
[max_hist, index_peak0] = max(hist_theta_rang);
index_peak = index_peak0 + ignore_range-1;
[max_hist1, index_peak1] = max(hist_theta);
window_size_original = 2+2+1; % 2+1+1;
index_left  = max(index_peak -2, 1);
index_right = min(index_peak +2, length(hist_theta));
window_size = index_right - index_left + 1;
sum(hist_theta(index_left:index_right))/sum(hist_theta);
plot(theta_range_now(index_left)*ones(1,10),[1:max_hist1/4.5:max_hist1*2.2],'r--','LineWidth',1);
plot(theta_range_now(index_right)*ones(1,10),[1:max_hist1/4.5:max_hist1*2.2],'r--','LineWidth',1);
ylim([0,max_hist1*1.1]);
sharpness = sum(hist_theta(index_left:index_right))/sum(hist_theta);
if index_left-2 > 0 && index_right+2 <= length(hist_theta)
    sharpness = mean(hist_theta(index_left:index_right))/mean(hist_theta(index_left-2:index_right+2));% /sum(hist_theta);
elseif index_left-2 <= 0
    sharpness = mean(hist_theta(index_left:index_right))/mean(hist_theta(index_left:index_right+4));% /sum(hist_theta);
elseif index_right+2 > length(hist_theta)
    sharpness = mean(hist_theta(index_left:index_right))/mean(hist_theta(index_left-4:index_right));% /sum(hist_theta);
end
set(gca,'XLim',[pi/2 pi],'fontsize',12,'fontname','Arial');
title(['Sharpness (pos):',num2str(sharpness)]);
dlmwrite(sharp,sharpness);
theta_range_now = theta_region(1:end-1) + pi/2; %  + pi;


disp("---------------")
ignore_range = 5;
ignore_center = 3;
disp(hist_theta_neg)
cent = length(theta_range_now)/2;
x = theta_range_now;
xx = theta_range_now([ignore_range : cent-ignore_center, cent+ ignore_center:end - ignore_range]);
y = hist_theta_neg;
yy = hist_theta_neg([ignore_range : cent-ignore_center, cent+ ignore_center:end - ignore_range]);% (ignore_range : end - ignore_range);
p = polyfit(xx,yy,1)
yfit =  p(1) * x  + p(2) ;%  + min(yy([ignore_range : end - ignore_range])); % min(yy); %
disp(y)
disp(yy)
hist_theta_neg = y - yfit;
hist_theta_neg = hist_theta_neg + abs(min(hist_theta_neg));
disp(hist_theta_neg)
disp("---------------")
figure(1);
subplot(2,2,4); plot(theta_range_now, hist_theta_neg,'b-','LineWidth',2); hold on;
ylabel('Sample Counts ')
xlabel('Theta')
hist_theta_rang = hist_theta_neg(ignore_range : end - ignore_range)
[max_hist1, index_peak1] = max(hist_theta_neg)
[max_hist, index_peak0] = max(hist_theta_rang)
index_peak = index_peak0 + ignore_range-1;
disp("----------------------")
disp(length(hist_theta_neg))
disp("----------------------")
window_size_original = 2+2+1; % 2+1+1;
index_left  = max(index_peak -2, 1)
index_right = min(index_peak +2, length(hist_theta_neg));
window_size = index_right - index_left ;
disp("----------------------")
disp(theta_range_now(index_left))
disp(theta_range_now(index_right))
disp(max_hist)
disp([max_hist:-max_hist/10:0])
disp("----------------------")
plot(theta_range_now(index_left)*ones(1,10), [-1.1*max_hist1:max_hist1/4.5:1.1*max_hist1],'r--','LineWidth',1);
plot(theta_range_now(index_right)*ones(1,10),[-1.1*max_hist1:max_hist1/4.5:1.1*max_hist1],'r--','LineWidth',1)
ylim([-100,max_hist1*1.1]);
if index_left-2 > 0 && index_right+2 <= length(hist_theta_neg)
    sharpness_neg = mean(hist_theta_neg(index_left:index_right))/mean(hist_theta_neg(index_left-2:index_right+2));% /sum(hist_theta_neg);
elseif index_left-2 <= 0
    sharpness_neg = mean(hist_theta_neg(index_left:index_right))/mean(hist_theta_neg(index_left:index_right+4));% /sum(hist_theta_neg);
elseif index_right+2 > length(hist_theta_neg)
    sharpness_neg = mean(hist_theta_neg(index_left:index_right))/mean(hist_theta_neg(index_left-4:index_right));% /sum(hist_theta_neg);
end
set(gca,'XLim',[pi/2 pi],'fontsize',12,'fontname','Arial');
title(['Sharpness (neg):',num2str(sharpness_neg)]);
dlmwrite(sharp2,sharpness_neg);


str = ['mkdir ',pathname,'/figure/;']; eval(str);
str = ['print -f10 -djpeg ',pathname,'/figure/SharpnessEtc_Orig_vs_Pred_',dataname(end-6:end-4);]; eval(str);
str = ['print -f10 -depsc ',pathname,'/figure/SharpnessEtc_Orig_vs_Pred_',dataname(end-6:end-4);]; eval(str);
str = ['print -f10 -dpdf ',pathname,'/figure/SharpnessEtc_Orig_vs_Pred_',dataname(end-6:end-4);]; eval(str);
str = ['print -f1 -djpeg ',pathname,'/figure/SharpnessEtc_',dataname(end-6:end-4);]; eval(str);
str = ['print -f1 -depsc ',pathname,'/figure/SharpnessEtc_',dataname(end-6:end-4);]; eval(str);
str = ['print -f1 -dpdf ',pathname,'/figure/SharpnessEtc_',dataname(end-6:end-4);]; eval(str);
dlmwrite(['posratio',dataname(end-6:end-4),'.txt'], posratio);
dlmwrite(['sharpness',dataname(end-6:end-4),'.txt'], sharpness);
str = ['copyfile posratio',dataname(end-6:end-4),'.txt ',pathname,'/'];
eval(str);
str = ['copyfile sharpness',dataname(end-6:end-4),'.txt ',pathname,'/'];
eval(str);
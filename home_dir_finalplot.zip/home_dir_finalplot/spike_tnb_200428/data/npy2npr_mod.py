""" 2020/02/18 go shibata
    2020/06/16 masanori shimono
make npr file
"""
def main(input):
    import os
    from argparse import ArgumentParser
    import numpy as np
    
    file = input
    parser = ArgumentParser()
  #  parser.add_argument('file')
    parser.add_argument(file)
    args = parser.parse_args()
    
    data = np.load(args.file)
    _, n_time, n_neuron = data.shape
    
    lines = [
        f'#nNeuron\t{n_neuron}',
        f'#nTime\t{n_time}',
    ]
    
    nz = data.nonzero()
    for _, time, dim in zip(*nz):
        lines.append(f'{time}\t{dim}')
    
  #  assert len(lines)-2 == len(nz[0])
    
    filename = f'{os.path.splitext(args.file)[0]}.txt'
    with open(filename, mode='w') as f:
        f.write('\n'.join(lines) + '\n')

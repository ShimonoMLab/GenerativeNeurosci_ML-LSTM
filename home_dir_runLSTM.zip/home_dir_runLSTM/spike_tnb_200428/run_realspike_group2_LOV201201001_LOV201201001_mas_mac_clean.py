
from src import dispatcher
import sys
import os
import numpy as np
import matplotlib

import matplotlib.pyplot as plt
import torch
import glob
import shutil   
import pandas as pd
import shutil
import copy

import load_asdf
import subprocess
import npr2npy_onlyspike

import spikes_div_weight_ver3 as div_weig_ryo

import spike2spike_split as s2ss

import npy2npr_mod3_func
import main_mod_func


for run_index in range(1, 5, 1):

    run_index
    os.chdir( "./" )
        
    region_id1 = "LOV"
    region_id2 = "LOV"
    region_date1 = "201201001"
    region_date2 = "201201001"
    
    region_id3 = "LOV"
    region_id4 = "LV"
    region_id5 = "LF"
    region_id6 = "LFD"
    region_id7 = "LD"
    region_id8 = "LOD"
    region_id9 = "ROD"
    region_id10 = "RD"
    region_id11 = "RFD"
    region_id12 = "RF"
    region_id13 = "RV"
    region_id14 = "ROV"
    region_id15 = "RO"
    region_id16 = "LFV"
    region_id17 = "RFV"
    region_id18 = "LO"
    
    region_date3 = "201201001"
    region_date4 = "201201001"
    


    if run_index == 1:
        epoch_num = 350
        rep_num = 1
        data_name_bf1 = "128neuron_rep" + str(rep_num) 
        data_name_bf2 = data_name_bf1 + "/" "Group2"+ region_id1 + str(region_date1) + "_" + region_id2 + str(region_date2)                 

        region_date1_s = region_date1[0:6]+region_date1[-1]
        region_date2_s = region_date2[0:6]+region_date2[-1]
        data_name_forconfig = "tr" + str(region_date1_s) + "_" + str(region_date2_s) + "_te" + str(region_date1_s)
        os.chdir("./data")

        os.chdir("./")

        for i in range(rep_num):
            data_name10 = list()
            data_name10.append(region_date1)
            data_name10.append(region_date2)

            for run_index2 in range(1, 5, 1):
                if run_index2 ==1:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id3 + str(region_date3)
                        data_name10.append(region_date3)
                        data_name10.append(region_date3)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==2:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id4 + str(region_date4)
                        data_name10.append(region_date4)
                        data_name10.append(region_date4)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==3:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id5 + str(region_date5)
                        data_name10.append(region_date5)
                        data_name10.append(region_date5)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==4:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id6 + str(region_date6)
                        data_name10.append(region_date6)
                        data_name10.append(region_date6)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==5:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id7 + str(region_date7)
                        data_name10.append(region_date7)
                        data_name10.append(region_date7)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==6:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id8 + str(region_date8)
                        data_name10.append(region_date8)
                        data_name10.append(region_date8)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==7:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id9 + str(region_date9)
                        data_name10.append(region_date9)
                        data_name10.append(region_date9)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==8:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id10 + str(region_date10)
                        data_name10.append(region_date10)
                        data_name10.append(region_date10)        
                        os.makedirs(data_name, exist_ok=True)         

                if run_index2 ==9:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id11 + str(region_date11)
                        data_name10.append(region_date11)
                        data_name10.append(region_date11)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==10:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id12 + str(region_date12)
                        data_name10.append(region_date12)
                        data_name10.append(region_date12)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==11:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id13 + str(region_date13)
                        data_name10.append(region_date13)
                        data_name10.append(region_date13)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==12:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id14 + str(region_date14)
                        data_name10.append(region_date14)
                        data_name10.append(region_date14)        
                        os.makedirs(data_name, exist_ok=True)  

                if run_index2 ==13:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id15 + str(region_date15)
                        data_name10.append(region_date15)
                        data_name10.append(region_date15)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==14:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id16 + str(region_date16)
                        data_name10.append(region_date16)
                        data_name10.append(region_date16)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==15:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id17 + str(region_date17)
                        data_name10.append(region_date17)
                        data_name10.append(region_date17)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==16:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id18 + str(region_date18)
                        data_name10.append(region_date18)
                        data_name10.append(region_date18)        
                        os.makedirs(data_name, exist_ok=True)  

                data_name10_fortransform = list()
                for i in range(1):
                    data_name10_fortransform.append(region_date1)
                    data_name10_fortransform.append(region_date2)

                rootdir = os.getcwd() +"/"

                os.chdir( "../../" )
                data_dir0 = os.getcwd() +"/Sharing_whole_SizeSame128/"
                os.chdir( "./spike_tnb_200428/data/" )
            #    data_dir0 = "/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/"
            #    data_dir0 = "./"

                data_dir_output = "../data/"
                print("data:" + data_name + ", epoch:" + str(epoch_num))
                file_list2="128_128_128_gamma002"+ "_epo" + str(epoch_num) 

                gen_dir = data_dir_output + str(data_name) +"/" + file_list2 +"/lstm_stack"
                if os.path.isdir(gen_dir):
                    print("We remove the original output directory before staring data loading.")
                    shutil.rmtree(gen_dir)
                    os.mkdir(gen_dir)   
                print("===========================================================================")
                for nnm in range(0,len(data_name10_fortransform)):
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"
                    
                    print("===========================================================================")
                    print("Now, changing data format upto spike0.npy")
                    print(nnm)
                    print("We once move to outout directory, to load necessary modules exsiting there.")
                    os.chdir( data_dir_output )

                    nNeuron1 = load_asdf.main(data_dir+"asdf.mat",data_dir+"npr2.txt" )
                    if nNeuron1 == -1:
                        print("If nNeuron == -1, run the following code in matlab" )
                        print("===========================================================================")
                        print("cd "+ data_dir)
                        print("load ./asdf" )
                        print("asdf = asdf"+"'")
                        print("save ./asdf asdf")
                        print("===========================================================================")
                    def npr2to3():
                        cmd = "./a.out "+ data_dir+"npr2.txt " + data_dir+"npr30.txt"
                        c = subprocess.check_output(cmd.split())
                    npr2to3()

                    npr2npy_onlyspike.main(data_dir,"npr30.txt")

                    os.chdir("../data/")

                for nnm in range(0,len(data_name10)):
                    print("===========================================================================")
                    print("Now, changing data format after spike0.npy... and combine among them.")
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"

                    data_length = 1_000_000 

                    used_steps_LSTM =                       round((data_length))   

                    sep_size = round((data_length)/(len(data_name10))) 
                    start_time_step = 2_000_000 + nnm * sep_size 
                    data_sep = []
                    data_sep = div_weig_ryo.main(data_dir,   len(data_name10), start_time_step  , used_steps_LSTM,sep_size)

                    def log10(input):
                        import math
                        return np.log10(input)

                #    cellcateg  = pd.read_csv(data_dir0+"{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header,sep=",")
                    cellcateg  = pd.read_csv(data_dir0+"/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header = None,sep=",")

                    aafr = pd.DataFrame(log10(np.sum(data_sep, axis =0)+1))
                    categ_num_fr = 1000  
                    fr_categ = np.floor( categ_num_fr * ( 1 - aafr / np.max(aafr) ) )
                    categ = categ_num_fr +1 + 2 *(cellcateg-0.5)*(categ_num_fr - fr_categ)  

                    categ1=categ.to_numpy()
                    bb_index = np.argsort(categ1, axis=0)
                    data_sep = data_sep[:, bb_index[:,0]]

                    if nnm == 0:

                        data_all = copy.copy(data_sep)
                    else:
                        data_all = np.append(data_all,data_sep, axis = 0)
                    print("Current data size is", (str(data_all.shape)))      

                os.makedirs("../data/"+ data_name, exist_ok=True)

                data_mix_dir = "../data/"+ data_name
                np.save(data_mix_dir+"/spikes.npy", data_all)

                segment_size = data_length 

                s2ss.main(data_mix_dir, segment_size )

                nNeuron = data_all.shape[1]

                print("===========================================================================")
                print("Now, copying config file") 
                os.chdir( "../" )

                shutil.copy("./data/config.ini" , "./data/config_" + str(data_name_forconfig) +".ini" )

                print("===========================================================================")
                print("Now, editing the config file")

                with open( "./data/config_" + str(data_name_forconfig) +".ini" ) as config_name:

                    data_lines = config_name.read()
                    data_lines = data_lines.replace("dim_input = 101", "dim_input = "+ str(nNeuron))

                    data_lines = data_lines.replace("n_epoch = 10", "n_epoch = " + str(epoch_num ))
                    data_lines = data_lines.replace("/n/work1/gshibata/src/spike_tnb_200424","./" )

                    data_lines = data_lines.replace("%(base)s/data/split_spikes.npy" , data_mix_dir + "/split_spikes.npy")

                    data_lines = data_lines.replace("%(base)s/data/result" ,  data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num))

                    data_lines = data_lines.replace("n_layer_list = 1,2,3", "n_layer_list = 1,1,1")
                    data_lines = data_lines.replace("n_hidden_list = 128,64,256", "n_hidden_list = 128,128,128")

                    data_lines = data_lines.replace("gamma = 0.0", "gamma = 0.02") 

                with open( "./data/config_" + str(data_name_forconfig) +".ini" , mode = "w" ) as config_name:

                    config_name.write(data_lines)
                print("===========================================================================")
                print("Now, running LSTM")

                os.chdir(rootdir)

                CONFIG_FILENAME =  "config_" + str(data_name_forconfig) + ".ini"

                CONFIG_PATH = os.path.join("data/", CONFIG_FILENAME)

                if run_index2 ==1:                
                    main_mod_func.main("lstm_stack","train","fromdata","sample", CONFIG_FILENAME )
                    data_mix_dir_index1 = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                else:
                    data_mix_dir_now = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                    shutil.copytree(data_mix_dir_index1, data_mix_dir_now) 

                main_mod_func.main("lstm_stack","generate","fromdata","sample", CONFIG_FILENAME )

                os.chdir(data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)+ "/lstm_stack")
                npy2npr_mod3_func.main("fromdata_sample_generated.npy","gener.txt")
                npy2npr_mod3_func.main("fromdata_sample_groundtruth.npy","truth.txt")
                os.chdir( gen_dir )

                loss_train_all    = np.zeros((epoch_num-1))
                accu_train_all    = np.zeros((epoch_num-1))
                accu_train_spike    = np.zeros((epoch_num-1))
                accu_train_nonspike = np.zeros((epoch_num-1))
                loss_valid_all    = np.zeros((epoch_num-1))
                accu_valid_all    = np.zeros((epoch_num-1))
                accu_valid_spike    = np.zeros((epoch_num-1))
                accu_valid_nonspike = np.zeros((epoch_num-1))

                def opentail(fn, n): 
                    with open(fn, "r") as f: 
                        f.readline() 
                        lines = f.readlines() 
                    return lines[-n]

                kk = 0

                for ll in range(0,epoch_num-1):

                    line= opentail("log.log", 2*kk+3)

                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_train_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_train_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))
                    xx10 = np.array(xx1[0])

                    accu_train_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])

                    accu_train_nonspike[epoch_num-kk-2]= xx20

                    print("[First] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))

                    line= opentail("log.log", 2*kk+2)
                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_valid_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_valid_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))

                    print("[Second] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))
                    xx10 = np.array(xx1[0])

                    accu_valid_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])
                    accu_valid_nonspike[epoch_num-kk-2]= xx20
                    kk = kk + 1
                    f = open('loss.txt', 'w')   
                    f.write(str(loss_train_all))     
                    f.write(str(loss_valid_all))
                    f.close()                

                plt.plot(loss_train_all.T,label="train",color="blue")
                plt.plot(loss_valid_all.T,label="valid",color="red")
                plt.yscale("log")
                plt.legend() 
                os.chdir( gen_dir )

                plt.savefig("loss_all.pdf")
                os.chdir(data_mix_dir)
                os.remove("spikes.npy")
                os.remove("split_spikes.npy")
                os.chdir( rootdir )

                torch.cuda.empty_cache()

    if run_index == 2:
        epoch_num = 350
        rep_num = 1
        data_name_bf1 = "128neuron_rep" + str(rep_num) 
        data_name_bf2 = data_name_bf1 + "/" "Group2"+ region_id1 + str(region_date1) + "_" + region_id2 + str(region_date2)                 

        region_date1_s = region_date1[0:6]+region_date1[-1]
        region_date2_s = region_date2[0:6]+region_date2[-1]
        data_name_forconfig = "tr" + str(region_date1_s) + "_" + str(region_date2_s) + "_te" + str(region_date1_s)
        os.chdir("./data")

        os.chdir("./")

        for i in range(rep_num):
            data_name10 = list()
            data_name10.append(region_date1)
            data_name10.append(region_date2)

            for run_index2 in range(5, 9, 1):
                if run_index2 ==1:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id3 + str(region_date3)
                        data_name10.append(region_date3)
                        data_name10.append(region_date3)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==2:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id4 + str(region_date4)
                        data_name10.append(region_date4)
                        data_name10.append(region_date4)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==3:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id5 + str(region_date5)
                        data_name10.append(region_date5)
                        data_name10.append(region_date5)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==4:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id6 + str(region_date6)
                        data_name10.append(region_date6)
                        data_name10.append(region_date6)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==5:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id7 + str(region_date7)
                        data_name10.append(region_date7)
                        data_name10.append(region_date7)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==6:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id8 + str(region_date8)
                        data_name10.append(region_date8)
                        data_name10.append(region_date8)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==7:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id9 + str(region_date9)
                        data_name10.append(region_date9)
                        data_name10.append(region_date9)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==8:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id10 + str(region_date10)
                        data_name10.append(region_date10)
                        data_name10.append(region_date10)        
                        os.makedirs(data_name, exist_ok=True)         

                if run_index2 ==9:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id11 + str(region_date11)
                        data_name10.append(region_date11)
                        data_name10.append(region_date11)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==10:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id12 + str(region_date12)
                        data_name10.append(region_date12)
                        data_name10.append(region_date12)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==11:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id13 + str(region_date13)
                        data_name10.append(region_date13)
                        data_name10.append(region_date13)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==12:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id14 + str(region_date14)
                        data_name10.append(region_date14)
                        data_name10.append(region_date14)        
                        os.makedirs(data_name, exist_ok=True)  

                if run_index2 ==13:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id15 + str(region_date15)
                        data_name10.append(region_date15)
                        data_name10.append(region_date15)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==14:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id16 + str(region_date16)
                        data_name10.append(region_date16)
                        data_name10.append(region_date16)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==15:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id17 + str(region_date17)
                        data_name10.append(region_date17)
                        data_name10.append(region_date17)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==16:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id18 + str(region_date18)
                        data_name10.append(region_date18)
                        data_name10.append(region_date18)        
                        os.makedirs(data_name, exist_ok=True)  

                data_name10_fortransform = list()
                for i in range(1):
                    data_name10_fortransform.append(region_date1)
                    data_name10_fortransform.append(region_date2)

                rootdir = os.getcwd() +"/"
#                data_dir0 = "/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/"
#                data_dir_output = "./data/"
                
                os.chdir( "../../" )
                data_dir0 = os.getcwd() +"/Sharing_whole_SizeSame128/"
                os.chdir( "./spike_tnb_200428/data/" )

                data_dir_output = "../data/"
                
                print("data:" + data_name + ", epoch:" + str(epoch_num))
                file_list2="128_128_128_gamma002"+ "_epo" + str(epoch_num) 

                gen_dir = data_dir_output + str(data_name) +"/" + file_list2 +"/lstm_stack"
                if os.path.isdir(gen_dir):
                    print("We remove the original output directory before staring data loading.")
                    shutil.rmtree(gen_dir)
                    os.mkdir(gen_dir)   
                print("===========================================================================")
                for nnm in range(0,len(data_name10_fortransform)):
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"
                    print("===========================================================================")
                    print("Now, changing data format upto spike0.npy")
                    print(nnm)
                    print("We once move to outout directory, to load necessary modules exsiting there.")
                    os.chdir( data_dir_output )

                    nNeuron1 = load_asdf.main(data_dir+"asdf.mat",data_dir+"npr2.txt" )
                    if nNeuron1 == -1:
                        print("If nNeuron == -1, run the following code in matlab" )
                        print("===========================================================================")
                        print("cd "+ data_dir)
                        print("load ./asdf" )
                        print("asdf = asdf"+"'")
                        print("save ./asdf asdf")
                        print("===========================================================================")
                    def npr2to3():
                        cmd = "./a.out "+ data_dir+"npr2.txt " + data_dir+"npr30.txt"
                        c = subprocess.check_output(cmd.split())
                    npr2to3()

                    npr2npy_onlyspike.main(data_dir,"npr30.txt")

                    os.chdir("./data/")

                for nnm in range(0,len(data_name10)):
                    print("===========================================================================")
                    print("Now, changing data format after spike0.npy... and combine among them.")
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"

                    data_length = 1_000_000 

                    used_steps_LSTM =                       round((data_length))   

                    sep_size = round((data_length)/(len(data_name10))) 
                    start_time_step = 2_000_000 + nnm * sep_size 
                    data_sep = []
                    data_sep = div_weig_ryo.main(data_dir,   len(data_name10), start_time_step  , used_steps_LSTM,sep_size)

                    def log10(input):
                        import math
                        return np.log10(input)

                    cellcateg  = pd.read_csv(data_dir0+"/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header=None,sep=",")
             #       layercateg = pd.read_csv(data_dir0+"/{}/layer_categ.txt".format(str(data_name10[nnm])),header=None,sep=",")
                    aafr = pd.DataFrame(log10(np.sum(data_sep, axis =0)+1))
                    categ_num_fr = 1000  
                    fr_categ = np.floor( categ_num_fr * ( 1 - aafr / np.max(aafr) ) )
                    categ = categ_num_fr +1 + 2 *(cellcateg-0.5)*(categ_num_fr - fr_categ)  

                    categ1=categ.to_numpy()
                    bb_index = np.argsort(categ1, axis=0)
                    data_sep = data_sep[:, bb_index[:,0]]

                    if nnm == 0:

                        data_all = copy.copy(data_sep)
                    else:
                        data_all = np.append(data_all,data_sep, axis = 0)
                    print("Current data size is", (str(data_all.shape)))      

                os.makedirs("./data/"+ data_name, exist_ok=True)

                data_mix_dir = "./data/"+ data_name
                np.save(data_mix_dir+"/spikes.npy", data_all)

                segment_size = data_length 

                s2ss.main(data_mix_dir, segment_size )

                nNeuron = data_all.shape[1]

                print("===========================================================================")
                print("Now, copying config file") 
                os.chdir( "./" )

                shutil.copy("./data/config.ini" , "./data/config_" + str(data_name_forconfig) +".ini" )

                print("===========================================================================")
                print("Now, editing the config file")

                with open( "./data/config_" + str(data_name_forconfig) +".ini" ) as config_name:

                    data_lines = config_name.read()
                    data_lines = data_lines.replace("dim_input = 101", "dim_input = "+ str(nNeuron))

                    data_lines = data_lines.replace("n_epoch = 10", "n_epoch = " + str(epoch_num ))
                    data_lines = data_lines.replace("/n/work1/gshibata/src/spike_tnb_200424","./" )

                    data_lines = data_lines.replace("%(base)s/data/split_spikes.npy" , data_mix_dir + "/split_spikes.npy")

                    data_lines = data_lines.replace("%(base)s/data/result" ,  data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num))

                    data_lines = data_lines.replace("n_layer_list = 1,2,3", "n_layer_list = 1,1,1")
                    data_lines = data_lines.replace("n_hidden_list = 128,64,256", "n_hidden_list = 128,128,128")

                    data_lines = data_lines.replace("gamma = 0.0", "gamma = 0.02") 

                with open( "./data/config_" + str(data_name_forconfig) +".ini" , mode = "w" ) as config_name:

                    config_name.write(data_lines)
                print("===========================================================================")
                print("Now, running LSTM")

                os.chdir(rootdir)

                CONFIG_FILENAME =  "config_" + str(data_name_forconfig) + ".ini"

                CONFIG_PATH = os.path.join("data/", CONFIG_FILENAME)

                if run_index2 ==1:                
                    main_mod_func.main("lstm_stack","train","fromdata","sample", CONFIG_FILENAME )
                    data_mix_dir_index1 = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                else:
                    data_mix_dir_now = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                    shutil.copytree(data_mix_dir_index1, data_mix_dir_now) 

                main_mod_func.main("lstm_stack","generate","fromdata","sample", CONFIG_FILENAME )

                os.chdir(data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)+ "/lstm_stack")
                npy2npr_mod3_func.main("fromdata_sample_generated.npy","gener.txt")
                npy2npr_mod3_func.main("fromdata_sample_groundtruth.npy","truth.txt")
                os.chdir( gen_dir )

                loss_train_all    = np.zeros((epoch_num-1))
                accu_train_all    = np.zeros((epoch_num-1))
                accu_train_spike    = np.zeros((epoch_num-1))
                accu_train_nonspike = np.zeros((epoch_num-1))
                loss_valid_all    = np.zeros((epoch_num-1))
                accu_valid_all    = np.zeros((epoch_num-1))
                accu_valid_spike    = np.zeros((epoch_num-1))
                accu_valid_nonspike = np.zeros((epoch_num-1))

                def opentail(fn, n): 
                    with open(fn, "r") as f: 
                        f.readline() 
                        lines = f.readlines() 
                    return lines[-n]

                kk = 0

                for ll in range(0,epoch_num-1):

                    line= opentail("log.log", 2*kk+3)

                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_train_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_train_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))
                    xx10 = np.array(xx1[0])

                    accu_train_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])

                    accu_train_nonspike[epoch_num-kk-2]= xx20

                    print("[First] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))

                    line= opentail("log.log", 2*kk+2)
                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_valid_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_valid_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))

                    print("[Second] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))
                    xx10 = np.array(xx1[0])

                    accu_valid_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])
                    accu_valid_nonspike[epoch_num-kk-2]= xx20
                    kk = kk + 1
                    f = open('loss.txt', 'w')   
                    f.write(str(loss_train_all))     
                    f.write(str(loss_valid_all))
                    f.close()                

                plt.plot(loss_train_all.T,label="train",color="blue")
                plt.plot(loss_valid_all.T,label="valid",color="red")
                plt.yscale("log")
                plt.legend() 
                os.chdir( gen_dir )

                plt.savefig("loss_all.pdf")
                os.chdir(data_mix_dir)
                os.remove("spikes.npy")
                os.remove("split_spikes.npy")
                os.chdir( rootdir )

                torch.cuda.empty_cache()

    if run_index == 3:
        epoch_num = 350
        rep_num = 1
        data_name_bf1 = "128neuron_rep" + str(rep_num) 
        data_name_bf2 = data_name_bf1 + "/" "Group2"+ region_id1 + str(region_date1) + "_" + region_id2 + str(region_date2)                 

        region_date1_s = region_date1[0:6]+region_date1[-1]
        region_date2_s = region_date2[0:6]+region_date2[-1]
        data_name_forconfig = "tr" + str(region_date1_s) + "_" + str(region_date2_s) + "_te" + str(region_date1_s)
        os.chdir("./data")

        os.chdir("./")

        for i in range(rep_num):
            data_name10 = list()
            data_name10.append(region_date1)
            data_name10.append(region_date2)

            for run_index2 in range(9, 13, 1):
                if run_index2 ==1:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id3 + str(region_date3)
                        data_name10.append(region_date3)
                        data_name10.append(region_date3)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==2:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id4 + str(region_date4)
                        data_name10.append(region_date4)
                        data_name10.append(region_date4)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==3:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id5 + str(region_date5)
                        data_name10.append(region_date5)
                        data_name10.append(region_date5)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==4:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id6 + str(region_date6)
                        data_name10.append(region_date6)
                        data_name10.append(region_date6)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==5:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id7 + str(region_date7)
                        data_name10.append(region_date7)
                        data_name10.append(region_date7)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==6:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id8 + str(region_date8)
                        data_name10.append(region_date8)
                        data_name10.append(region_date8)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==7:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id9 + str(region_date9)
                        data_name10.append(region_date9)
                        data_name10.append(region_date9)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==8:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id10 + str(region_date10)
                        data_name10.append(region_date10)
                        data_name10.append(region_date10)        
                        os.makedirs(data_name, exist_ok=True)         

                if run_index2 ==9:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id11 + str(region_date11)
                        data_name10.append(region_date11)
                        data_name10.append(region_date11)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==10:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id12 + str(region_date12)
                        data_name10.append(region_date12)
                        data_name10.append(region_date12)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==11:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id13 + str(region_date13)
                        data_name10.append(region_date13)
                        data_name10.append(region_date13)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==12:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id14 + str(region_date14)
                        data_name10.append(region_date14)
                        data_name10.append(region_date14)        
                        os.makedirs(data_name, exist_ok=True)  

                if run_index2 ==13:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id15 + str(region_date15)
                        data_name10.append(region_date15)
                        data_name10.append(region_date15)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==14:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id16 + str(region_date16)
                        data_name10.append(region_date16)
                        data_name10.append(region_date16)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==15:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id17 + str(region_date17)
                        data_name10.append(region_date17)
                        data_name10.append(region_date17)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==16:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id18 + str(region_date18)
                        data_name10.append(region_date18)
                        data_name10.append(region_date18)        
                        os.makedirs(data_name, exist_ok=True)  

                data_name10_fortransform = list()
                for i in range(1):
                    data_name10_fortransform.append(region_date1)
                    data_name10_fortransform.append(region_date2)

                rootdir = os.getcwd() +"/"

                os.chdir( "../../" )
                data_dir0 = os.getcwd() +"/Sharing_whole_SizeSame128/"
                
                os.chdir( "./spike_tnb_200428/data/" )

                data_dir_output = "../data/"
                
              #  data_dir0 = "/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/"

                data_dir_output = "./data/"
                print("data:" + data_name + ", epoch:" + str(epoch_num))
                file_list2="128_128_128_gamma002"+ "_epo" + str(epoch_num) 

                gen_dir = data_dir_output + str(data_name) +"/" + file_list2 +"/lstm_stack"
                if os.path.isdir(gen_dir):
                    print("We remove the original output directory before staring data loading.")
                    shutil.rmtree(gen_dir)
                    os.mkdir(gen_dir)   
                print("===========================================================================")
                for nnm in range(0,len(data_name10_fortransform)):
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"
                    print("===========================================================================")
                    print("Now, changing data format upto spike0.npy")
                    print(nnm)
                    print("We once move to outout directory, to load necessary modules exsiting there.")
                    os.chdir( data_dir_output )

                    nNeuron1 = load_asdf.main(data_dir+"asdf.mat",data_dir+"npr2.txt" )
                    if nNeuron1 == -1:
                        print("If nNeuron == -1, run the following code in matlab" )
                        print("===========================================================================")
                        print("cd "+ data_dir)
                        print("load ./asdf" )
                        print("asdf = asdf"+"'")
                        print("save ./asdf asdf")
                        print("===========================================================================")
                    def npr2to3():
                        cmd = "./a.out "+ data_dir+"npr2.txt " + data_dir+"npr30.txt"
                        c = subprocess.check_output(cmd.split())
                    npr2to3()

                    npr2npy_onlyspike.main(data_dir,"npr30.txt")

                    os.chdir("./data/")

                for nnm in range(0,len(data_name10)):
                    print("===========================================================================")
                    print("Now, changing data format after spike0.npy... and combine among them.")
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"

                    data_length = 1_000_000 

                    used_steps_LSTM =                       round((data_length))   

                    sep_size = round((data_length)/(len(data_name10))) 
                    start_time_step = 2_000_000 + nnm * sep_size 
                    data_sep = []
                    data_sep = div_weig_ryo.main(data_dir,   len(data_name10), start_time_step  , used_steps_LSTM,sep_size)

                    def log10(input):
                        import math
                        return np.log10(input)

                    cellcateg  = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header = None,sep=",")
            #        cellcateg  = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header = None,sep=",")
            #        layercateg = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/layer_categ.txt".format(str(data_name10[nnm])),header = None,sep=",")
            
                    aafr = pd.DataFrame(log10(np.sum(data_sep, axis =0)+1))
                    categ_num_fr = 1000  
                    fr_categ = np.floor( categ_num_fr * ( 1 - aafr / np.max(aafr) ) )
                    categ = categ_num_fr +1 + 2 *(cellcateg-0.5)*(categ_num_fr - fr_categ)  

                    categ1=categ.to_numpy()
                    bb_index = np.argsort(categ1, axis=0)
                    data_sep = data_sep[:, bb_index[:,0]]

                    if nnm == 0:

                        data_all = copy.copy(data_sep)
                    else:
                        data_all = np.append(data_all,data_sep, axis = 0)
                    print("Current data size is", (str(data_all.shape)))      

                os.makedirs("./data/"+ data_name, exist_ok=True)

                data_mix_dir = "./data/"+ data_name
                np.save(data_mix_dir+"/spikes.npy", data_all)

                segment_size = data_length 

                s2ss.main(data_mix_dir, segment_size )

                nNeuron = data_all.shape[1]

                print("===========================================================================")
                print("Now, copying config file") 
                os.chdir( "./" )

                shutil.copy("./data/config.ini" , "./data/config_" + str(data_name_forconfig) +".ini" )

                print("===========================================================================")
                print("Now, editing the config file")

                with open( "./data/config_" + str(data_name_forconfig) +".ini" ) as config_name:

                    data_lines = config_name.read()
                    data_lines = data_lines.replace("dim_input = 101", "dim_input = "+ str(nNeuron))

                    data_lines = data_lines.replace("n_epoch = 10", "n_epoch = " + str(epoch_num ))
                    data_lines = data_lines.replace("/n/work1/gshibata/src/spike_tnb_200424","./" )

                    data_lines = data_lines.replace("%(base)s/data/split_spikes.npy" , data_mix_dir + "/split_spikes.npy")

                    data_lines = data_lines.replace("%(base)s/data/result" ,  data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num))

                    data_lines = data_lines.replace("n_layer_list = 1,2,3", "n_layer_list = 1,1,1")
                    data_lines = data_lines.replace("n_hidden_list = 128,64,256", "n_hidden_list = 128,128,128")

                    data_lines = data_lines.replace("gamma = 0.0", "gamma = 0.02") 

                with open( "./data/config_" + str(data_name_forconfig) +".ini" , mode = "w" ) as config_name:

                    config_name.write(data_lines)
                print("===========================================================================")
                print("Now, running LSTM")

                os.chdir(rootdir)

                CONFIG_FILENAME =  "config_" + str(data_name_forconfig) + ".ini"

                CONFIG_PATH = os.path.join("data/", CONFIG_FILENAME)

                if run_index2 ==1:                
                    main_mod_func.main("lstm_stack","train","fromdata","sample", CONFIG_FILENAME )
                    data_mix_dir_index1 = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                else:
                    data_mix_dir_now = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                    shutil.copytree(data_mix_dir_index1, data_mix_dir_now) 

                main_mod_func.main("lstm_stack","generate","fromdata","sample", CONFIG_FILENAME )

                os.chdir(data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)+ "/lstm_stack")
                npy2npr_mod3_func.main("fromdata_sample_generated.npy","gener.txt")
                npy2npr_mod3_func.main("fromdata_sample_groundtruth.npy","truth.txt")
                os.chdir( gen_dir )

                loss_train_all    = np.zeros((epoch_num-1))
                accu_train_all    = np.zeros((epoch_num-1))
                accu_train_spike    = np.zeros((epoch_num-1))
                accu_train_nonspike = np.zeros((epoch_num-1))
                loss_valid_all    = np.zeros((epoch_num-1))
                accu_valid_all    = np.zeros((epoch_num-1))
                accu_valid_spike    = np.zeros((epoch_num-1))
                accu_valid_nonspike = np.zeros((epoch_num-1))

                def opentail(fn, n): 
                    with open(fn, "r") as f: 
                        f.readline() 
                        lines = f.readlines() 
                    return lines[-n]

                kk = 0

                for ll in range(0,epoch_num-1):

                    line= opentail("log.log", 2*kk+3)

                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_train_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_train_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))
                    xx10 = np.array(xx1[0])

                    accu_train_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])

                    accu_train_nonspike[epoch_num-kk-2]= xx20

                    print("[First] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))

                    line= opentail("log.log", 2*kk+2)
                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_valid_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_valid_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))

                    print("[Second] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))
                    xx10 = np.array(xx1[0])

                    accu_valid_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])
                    accu_valid_nonspike[epoch_num-kk-2]= xx20
                    kk = kk + 1
                    f = open('loss.txt', 'w')   
                    f.write(str(loss_train_all))     
                    f.write(str(loss_valid_all))
                    f.close()                

                plt.plot(loss_train_all.T,label="train",color="blue")
                plt.plot(loss_valid_all.T,label="valid",color="red")
                plt.yscale("log")
                plt.legend() 
                os.chdir( gen_dir )

                plt.savefig("loss_all.pdf")
                os.chdir(data_mix_dir)
                os.remove("spikes.npy")
                os.remove("split_spikes.npy")
                os.chdir( rootdir )

                torch.cuda.empty_cache()

    if run_index == 4:
        epoch_num = 350
        rep_num = 1
        data_name_bf1 = "128neuron_rep" + str(rep_num) 
        data_name_bf2 = data_name_bf1 + "/" "Group2"+ region_id1 + str(region_date1) + "_" + region_id2 + str(region_date2)                 

        region_date1_s = region_date1[0:6]+region_date1[-1]
        region_date2_s = region_date2[0:6]+region_date2[-1]
        data_name_forconfig = "tr" + str(region_date1_s) + "_" + str(region_date2_s) + "_te" + str(region_date1_s)
        os.chdir("./data")

        os.chdir("./")

        for i in range(rep_num):
            data_name10 = list()
            data_name10.append(region_date1)
            data_name10.append(region_date2)

            for run_index2 in range(13, 17, 1):
                if run_index2 ==1:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id3 + str(region_date3)
                        data_name10.append(region_date3)
                        data_name10.append(region_date3)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==2:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id4 + str(region_date4)
                        data_name10.append(region_date4)
                        data_name10.append(region_date4)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==3:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id5 + str(region_date5)
                        data_name10.append(region_date5)
                        data_name10.append(region_date5)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==4:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id6 + str(region_date6)
                        data_name10.append(region_date6)
                        data_name10.append(region_date6)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==5:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id7 + str(region_date7)
                        data_name10.append(region_date7)
                        data_name10.append(region_date7)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==6:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id8 + str(region_date8)
                        data_name10.append(region_date8)
                        data_name10.append(region_date8)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==7:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id9 + str(region_date9)
                        data_name10.append(region_date9)
                        data_name10.append(region_date9)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==8:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id10 + str(region_date10)
                        data_name10.append(region_date10)
                        data_name10.append(region_date10)        
                        os.makedirs(data_name, exist_ok=True)         

                if run_index2 ==9:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id11 + str(region_date11)
                        data_name10.append(region_date11)
                        data_name10.append(region_date11)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==10:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id12 + str(region_date12)
                        data_name10.append(region_date12)
                        data_name10.append(region_date12)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==11:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id13 + str(region_date13)
                        data_name10.append(region_date13)
                        data_name10.append(region_date13)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==12:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id14 + str(region_date14)
                        data_name10.append(region_date14)
                        data_name10.append(region_date14)        
                        os.makedirs(data_name, exist_ok=True)  

                if run_index2 ==13:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id15 + str(region_date15)
                        data_name10.append(region_date15)
                        data_name10.append(region_date15)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==14:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id16 + str(region_date16)
                        data_name10.append(region_date16)
                        data_name10.append(region_date16)        
                        os.makedirs(data_name, exist_ok=True)     

                if run_index2 ==15:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id17 + str(region_date17)
                        data_name10.append(region_date17)
                        data_name10.append(region_date17)
                        os.makedirs(data_name, exist_ok=True)

                if run_index2 ==16:            
                    for j in range(rep_num):
                        data_name  = data_name_bf2 + "/" + region_id18 + str(region_date18)
                        data_name10.append(region_date18)
                        data_name10.append(region_date18)        
                        os.makedirs(data_name, exist_ok=True)  

                data_name10_fortransform = list()
                for i in range(1):
                    data_name10_fortransform.append(region_date1)
                    data_name10_fortransform.append(region_date2)

                rootdir = os.getcwd() +"/"

                os.chdir( "../../" )
                data_dir0 = os.getcwd() +"/Sharing_whole_SizeSame128/"
                os.chdir( "./spike_tnb_200428/data/" )
                data_dir_output = "../data/"
                
             #   data_dir0 = "/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/"
             #   data_dir_output = "./data/"
                
                print("data:" + data_name + ", epoch:" + str(epoch_num))
                file_list2="128_128_128_gamma002"+ "_epo" + str(epoch_num) 

                gen_dir = data_dir_output + str(data_name) +"/" + file_list2 +"/lstm_stack"
                if os.path.isdir(gen_dir):
                    print("We remove the original output directory before staring data loading.")
                    shutil.rmtree(gen_dir)
                    os.mkdir(gen_dir)   
                print("===========================================================================")
                for nnm in range(0,len(data_name10_fortransform)):
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"
                    print("===========================================================================")
                    print("Now, changing data format upto spike0.npy")
                    print(nnm)
                    print("We once move to outout directory, to load necessary modules exsiting there.")
                    os.chdir( data_dir_output )

                    nNeuron1 = load_asdf.main(data_dir+"asdf.mat",data_dir+"npr2.txt" )
                    if nNeuron1 == -1:
                        print("If nNeuron is -1, run the following code in matlab" )
                        print("===========================================================================")
                        print("cd "+ data_dir)
                        print("load ./asdf" )
                        print("asdf = asdf"+"'")
                        print("save ./asdf asdf")
                        print("===========================================================================")
                    def npr2to3():
                        cmd = "./a.out "+ data_dir+"npr2.txt " + data_dir+"npr30.txt"
                        c = subprocess.check_output(cmd.split())
                    npr2to3()

                    npr2npy_onlyspike.main(data_dir,"npr30.txt")

                    os.chdir("./data/")

                for nnm in range(0,len(data_name10)):
                    print("===========================================================================")
                    print("Now, changing data format after spike0.npy... and combine among them.")
                    data_dir = data_dir0 + str(data_name10[nnm]) +"/"

                    data_length = 1_000_000 

                    used_steps_LSTM =                       round((data_length))   

                    sep_size = round((data_length)/(len(data_name10))) 
                    start_time_step = 2_000_000 + nnm * sep_size 
                    data_sep = []
                    data_sep = div_weig_ryo.main(data_dir,   len(data_name10), start_time_step  , used_steps_LSTM,sep_size)

                    def log10(input):
                        import math
                        return np.log10(input)

                    cellcateg  = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header = None,sep=",")
           #         cellcateg  = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/cell_categ_exc.txt".format(str(data_name10[nnm])),header,sep=",")
           #         layercateg = pd.read_csv("/Applications/python_home/200410_Music_Naka/test/Sharing_whole_SizeSame128/{}/layer_categ.txt".format(str(data_name10[nnm])),header = None,sep=",")
                    aafr = pd.DataFrame(log10(np.sum(data_sep, axis =0)+1))
                    categ_num_fr = 1000  
                    fr_categ = np.floor( categ_num_fr * ( 1 - aafr / np.max(aafr) ) )
                    categ = categ_num_fr +1 + 2 *(cellcateg-0.5)*(categ_num_fr - fr_categ)  

                    categ1=categ.to_numpy()
                    bb_index = np.argsort(categ1, axis=0)
                    data_sep = data_sep[:, bb_index[:,0]]

                    if nnm == 0:

                        data_all = copy.copy(data_sep)
                    else:
                        data_all = np.append(data_all,data_sep, axis = 0)
                    print("Current data size is", (str(data_all.shape)))      

                os.makedirs("./data/"+ data_name, exist_ok=True)

                data_mix_dir = "./data/"+ data_name
                np.save(data_mix_dir+"/spikes.npy", data_all)

                segment_size = data_length 

                s2ss.main(data_mix_dir, segment_size )

                nNeuron = data_all.shape[1]

                print("===========================================================================")
                print("Now, copying config file") 
                os.chdir( "./" )

                shutil.copy("./data/config.ini" , "./data/config_" + str(data_name_forconfig) +".ini" )

                print("===========================================================================")
                print("Now, editing the config file")

                with open( "./data/config_" + str(data_name_forconfig) +".ini" ) as config_name:

                    data_lines = config_name.read()
                    data_lines = data_lines.replace("dim_input = 101", "dim_input = "+ str(nNeuron))

                    data_lines = data_lines.replace("n_epoch = 10", "n_epoch = " + str(epoch_num ))
                    data_lines = data_lines.replace("/n/work1/gshibata/src/spike_tnb_200424","./" )

                    data_lines = data_lines.replace("%(base)s/data/split_spikes.npy" , data_mix_dir + "/split_spikes.npy")

                    data_lines = data_lines.replace("%(base)s/data/result" ,  data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num))

                    data_lines = data_lines.replace("n_layer_list = 1,2,3", "n_layer_list = 1,1,1")
                    data_lines = data_lines.replace("n_hidden_list = 128,64,256", "n_hidden_list = 128,128,128")

                    data_lines = data_lines.replace("gamma = 0.0", "gamma = 0.02") 

                with open( "./data/config_" + str(data_name_forconfig) +".ini" , mode = "w" ) as config_name:

                    config_name.write(data_lines)
                print("===========================================================================")
                print("Now, running LSTM")

                os.chdir(rootdir)

                CONFIG_FILENAME =  "config_" + str(data_name_forconfig) + ".ini"

                CONFIG_PATH = os.path.join("data/", CONFIG_FILENAME)

                if run_index2 ==1:                
                    main_mod_func.main("lstm_stack","train","fromdata","sample", CONFIG_FILENAME )
                    data_mix_dir_index1 = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                else:
                    data_mix_dir_now = data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)
                    shutil.copytree(data_mix_dir_index1, data_mix_dir_now) 

                main_mod_func.main("lstm_stack","generate","fromdata","sample", CONFIG_FILENAME )

                os.chdir(data_mix_dir + "/128_128_128_gamma002"+ "_epo" + str(epoch_num)+ "/lstm_stack")
                npy2npr_mod3_func.main("fromdata_sample_generated.npy","gener.txt")
                npy2npr_mod3_func.main("fromdata_sample_groundtruth.npy","truth.txt")
                os.chdir( gen_dir )

                loss_train_all    = np.zeros((epoch_num-1))
                accu_train_all    = np.zeros((epoch_num-1))
                accu_train_spike    = np.zeros((epoch_num-1))
                accu_train_nonspike = np.zeros((epoch_num-1))
                loss_valid_all    = np.zeros((epoch_num-1))
                accu_valid_all    = np.zeros((epoch_num-1))
                accu_valid_spike    = np.zeros((epoch_num-1))
                accu_valid_nonspike = np.zeros((epoch_num-1))

                def opentail(fn, n): 
                    with open(fn, "r") as f: 
                        f.readline() 
                        lines = f.readlines() 
                    return lines[-n]

                kk = 0

                for ll in range(0,epoch_num-1):

                    line= opentail("log.log", 2*kk+3)

                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_train_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_train_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))
                    xx10 = np.array(xx1[0])

                    accu_train_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])

                    accu_train_nonspike[epoch_num-kk-2]= xx20

                    print("[First] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))

                    line= opentail("log.log", 2*kk+2)
                    line=line.replace("nan",str(0))
                    ini0loss = line.find("loss:")
                    ini0 = line.find("all")
                    ini1 = line.find("spike")
                    ini2 = line.find("nonspike")
                    xx0loss = list(map(float,(line[ini0loss+6:ini0-10].split("\t"))))
                    xx00loss = np.array(xx0loss[0])

                    loss_valid_all[epoch_num-kk-2] = xx00loss
                    xx0 = list(map(float,(line[ini0+6:ini1-5].split("\t"))))
                    xx00 = np.array(xx0[0])

                    accu_valid_all[epoch_num-kk-2] = xx00

                    xx1 = list(map(float,(line[ini1+7:ini2-3].split("\t"))))

                    print("[Second] all: " + str(xx00) +", spike: " + str(xx10) + ", nonspike: " + str(xx20))
                    xx10 = np.array(xx1[0])

                    accu_valid_spike[epoch_num-kk-2] = xx10
                    xx2 = list(map(float,(line[ini2+10:ini2+20].split("\t"))))
                    xx20 = np.array(xx2[0])
                    accu_valid_nonspike[epoch_num-kk-2]= xx20
                    kk = kk + 1
                    f = open('loss.txt', 'w')   
                    f.write(str(loss_train_all))     
                    f.write(str(loss_valid_all))
                    f.close()                

                plt.plot(loss_train_all.T,label="train",color="blue")
                plt.plot(loss_valid_all.T,label="valid",color="red")
                plt.yscale("log")
                plt.legend() 
                os.chdir( gen_dir )

                plt.savefig("loss_all.pdf")
                os.chdir(data_mix_dir)
                os.remove("spikes.npy")
                os.remove("split_spikes.npy")
                os.chdir( rootdir )

                torch.cuda.empty_cache()



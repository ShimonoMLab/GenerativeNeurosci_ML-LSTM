import torch
from torch import nn


class LSTM(nn.Module):

    def __init__(self, n_input, n_lstm_hidden, n_output):
        super().__init__()

        self.lstm = nn.LSTM(input_size=n_input, hidden_size=n_lstm_hidden,
                            batch_first=True, num_layers=1)
        self.fc = nn.Linear(n_lstm_hidden, n_output)
        
        
        self.sigmoid = nn.Sigmoid()

    def forward(self, inputs, hidden0=None):
        self.lstm.flatten_parameters()
        outputs, hidden = self.lstm(inputs, hidden0)
        x = self.fc(outputs)
        x = self.sigmoid(x)
        return x, hidden

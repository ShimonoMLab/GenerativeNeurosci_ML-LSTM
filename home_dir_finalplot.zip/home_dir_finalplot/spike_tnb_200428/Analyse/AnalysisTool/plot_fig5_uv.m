
close all;
clear all;

for groupID = 1:2
    
    if groupID == 1
        
        load ../../data/128neuron_16_!6_eval/data_neg_sharpness
        load ../../data/128neuron_16_!6_eval/data_pos_sharpness
        load ../../conn_all
        
    elseif groupID == 2
        
        load ../../data/128neuron_16_!6_eval/data_neg_sharpness_group2
        load ../../data/128neuron_16_!6_eval/data_pos_sharpness_group2
        load ../../conn_all_group2
    end
    
    
    data_neg = data_neg(9:16,9:16);
    data_pos = data_pos(9:16,9:16);
    
    conn_strength_mat = conn_all(9:16,9:16);
    
    mkdir ../../figure
    
    figure(14 )
    subplot(2,2,1);
    plot(conn_strength_mat, data_pos,'r.'); hold on;
    title('pos')
    xlabel('Direct connection strength');
    ylabel('Sharpness prediction performance [log_{10}]','FontSize',9);
    
    subplot(2,2,2);
    plot(conn_strength_mat, data_neg,'b.'); hold on;
    title('neg')
    xlabel('Direct connection strength');
    ylabel('Sharpness prediction performance [log_{10}]','FontSize',9);
    subplot(2,2,3);
    title(['Group',num2str(groupID)])
    
    disp("----------------------------")
    disp([num2str(conn_strength_mat)]);
    disp("----------------------------")
    disp([num2str(data_neg) ]);
    disp("----------------------------")
    disp([num2str(data_pos) ]);
    disp("----------------------------")
    
    
    conn_strength_mat0(groupID,:,:) = conn_strength_mat;
    data_neg0(groupID,:,:) = data_neg;
    data_pos0(groupID,:,:) = data_pos;
    
    clear data_neg data_pos  conn_strength_mat
    
    
end

print -f14 -djpeg ../../figure/Sharpnesspred_ve_connection_hemiR_group12
print -f14 -deps  ../../figure/Sharpnesspred_ve_connection_hemiR_group12
print -f14 -dpdf  ../../figure/Sharpnesspred_ve_connection_hemiR_group12


conn_strength_mat = squeeze(mean(conn_strength_mat0));
data_neg = squeeze(mean(data_neg0));
data_pos = squeeze(mean(data_pos0));


%%

disp("----------------------------")
disp([num2str(conn_strength_mat0)]);
disp("----------------------------")
disp([num2str(data_neg0) ]);
disp("----------------------------")
disp([num2str(data_pos0) ]);
disp("----------------------------")

conn_str2      = reshape(conn_strength_mat0,128,1);
sharpness_neg2 = reshape(data_neg0,128,1);
sharpness_pos2 = reshape(data_pos0,128,1);

disp("----------------------------")
disp([num2str(conn_str2)]);
disp("----------------------------")
disp([num2str(sharpness_neg2) ]);
disp("----------------------------")
disp([num2str(sharpness_pos2) ]);
disp("----------------------------")
% rng('default')


[r_pos,p_pos] = corr(conn_str2,sharpness_pos2,'Type','Spearman')

[r_neg,p_neg] = corr(conn_str2,sharpness_neg2,'Type','Spearman')

disp(["condition RandL **: r =",num2str(r_pos) , "p =",num2str(p_pos)]);
disp(["condition RandL **: r =",num2str(r_neg) , "p =",num2str(p_neg)]);



